# MOLGENIS Compute 5.x Documentation

Licence: LGPLv3. http://www.molgenis.org

The MOLGENIS Compute 5 User Guide is available at <a href="https://rawgithub.com/georgebyelas/molgenis/master/molgenis-compute-core/README.html"> Molgenis Compute 5 User Guide</a>

