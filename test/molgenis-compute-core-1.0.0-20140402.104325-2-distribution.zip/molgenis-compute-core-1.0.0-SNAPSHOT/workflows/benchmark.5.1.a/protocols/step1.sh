#string gu
#string hap
#output out1
#output out2

# Let's do something nice
echo "${gu} is going to ${hap}"
out1="${gu}"
out2="${hap}"
