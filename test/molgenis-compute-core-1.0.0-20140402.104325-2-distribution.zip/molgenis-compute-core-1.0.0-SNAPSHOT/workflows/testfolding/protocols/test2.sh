#string chr
#list chunk

for s in "${chunk[@]}"
do
    echo ${s}
done