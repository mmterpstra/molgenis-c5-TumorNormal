#string chunk
#list chr

for s in "${chr[@]}"
do
    echo ${s}
done