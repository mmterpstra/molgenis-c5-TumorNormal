#string chr
#string chunk
#output outputLALA

outputLALA=${chr}_outvalue

