#string local_chr
#list concat

for s in "${concat[@]}"
do
    echo ${s}
    echo ${local_chr}
done