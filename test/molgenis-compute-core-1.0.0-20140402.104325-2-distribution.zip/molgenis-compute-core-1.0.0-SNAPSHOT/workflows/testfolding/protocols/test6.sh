#string chr
#list runtime_concat

for s in "${runtime_concat[@]}"
do
    echo ${s}
done