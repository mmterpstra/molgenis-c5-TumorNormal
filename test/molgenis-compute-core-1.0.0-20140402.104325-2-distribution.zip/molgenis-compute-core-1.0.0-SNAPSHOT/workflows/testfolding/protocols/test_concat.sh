#string chr
#list concat

for s in "${concat[@]}"
do
    echo ${s}
done