#string sample
#string sampleCopy

echo "We are now in stepC.sh and echo all samples and a copy of their name made in stepA:"
echo "sample: $sample, sampleCopy: $sampleCopy"