#string input

# Let's do something with string 'in'
echo "${input}_hasBeenInStep1"
${extra_variable}