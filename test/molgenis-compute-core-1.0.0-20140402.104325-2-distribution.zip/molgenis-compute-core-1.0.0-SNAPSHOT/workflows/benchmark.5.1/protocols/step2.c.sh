#string workflowName
#string creationDate
#string out

echo "Workflow name: ${workflowName}"
echo "Created: ${creationDate}"

echo "Result of step1.sh:"
echo ${out}


echo "(FOR TESTING PURPOSES: your runid is ${runid})"