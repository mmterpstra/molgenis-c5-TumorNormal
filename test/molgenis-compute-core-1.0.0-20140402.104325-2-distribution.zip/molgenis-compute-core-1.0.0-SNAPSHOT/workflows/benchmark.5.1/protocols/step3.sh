#string mytool

echo "I am using ${mytool}"

