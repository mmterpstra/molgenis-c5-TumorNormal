#string input_input
#output out

# Let's do something with string 'in'
echo "${input_input}_hasBeenInStep1"
out=${input_input}_hasBeenInStep1