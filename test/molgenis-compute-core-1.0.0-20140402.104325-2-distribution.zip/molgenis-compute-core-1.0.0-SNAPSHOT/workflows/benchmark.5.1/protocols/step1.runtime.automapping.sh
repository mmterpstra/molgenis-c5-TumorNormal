#string input
#output out_out

# Let's do something with string 'in'
echo "${input}_hasBeenInStep1"
out_out=${input}_hasBeenInStep1