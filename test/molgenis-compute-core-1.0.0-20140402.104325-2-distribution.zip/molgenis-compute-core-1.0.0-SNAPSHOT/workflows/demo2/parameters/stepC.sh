#string nSamples

echo "StepC.sh: $nSamples"