#list descriptiveSampleNames

echo ""
for s in ${descriptiveSampleNames[@]}
do
	echo "StepB.sh: Sample '${s}'"
done