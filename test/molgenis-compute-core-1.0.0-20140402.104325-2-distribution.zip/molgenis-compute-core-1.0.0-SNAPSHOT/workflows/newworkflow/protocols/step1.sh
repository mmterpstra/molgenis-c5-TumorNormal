#input in
#output out

# Let's do something with string 'in'
out=${in}_hasBeenInStep1